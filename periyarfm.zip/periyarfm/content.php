<?php
/*$con=mysqli_connect("localhost","fm_periyarfm","4U0VIf4yAxm4","fm_periyarfm");
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
//mysqli_set_charset($con,"utf8");
if (!$con->set_charset("utf8")) {
    printf("Error loading character set utf8: %s\n", $con->error);
    exit();
} else {
    //printf("Current character set: %s\n", $con->character_set_name());
}
$selectcategories="select Category_Id,Category_Name from category_manager where Status!=0";
$selectcategoriesexe=mysqli_query($con,$selectcategories);
if(!$selectcategories){
	echo  mysqli_error($con);
}
$count=mysqli_num_rows($selectcategoriesexe);
if($count>0)
{

while($row1=mysqli_fetch_array($selectcategoriesexe,MYSQL_BOTH))
{
		$select='select Distinct Audio_Id,Audio_Album,Audio_File,Audio_Title,Audio_Descript,Category_Name,am.Category_Id from audio_manager as am,category_manager as cm where am.Category_Id=cm.Category_Id and cm.Category_Id='.$row1["0"].' order by Audio_Id Desc Limit 0,11';
		$exe=mysqli_query($con,$select);
		if(!$exe)
		{
		echo mysqli_error($con);
		}
		$cnt=mysqli_num_rows($exe);
		if($cnt>0)
		{
			$eprint='';
			$eprint.='<meta charset="utf-8"><h4>'.$row1["1"].'</h4>';
			  $eprint.='<div class="well">
            <div id="myCarousel" class="carousel slide">           
                <div class="carousel-inner">
				<div class="item active">
                   <div class="row">';
				$i=0;
			while($row=mysqli_fetch_array($exe,MYSQL_BOTH))
			{	

                   $eprint.='<div class="col-sm-2"><img src="http://periyar.fm/admin/upload/image_file/'.$row[1].'" class="img-responsive thumbnail" id="'.$row[0].'"data-audio=http://periyar.fm/admin/upload/audio_file/'.$row[2].' data-atitle="'.$row[3].'" onclick="playthis(this.id)" style="cursor:pointer;"> 
                            </div>';
							//echo '<img src="http://periyar.fm/admin/upload/image_file/'.$row[1].'" class="img-responsive" id="'.$row[0].'"data-audio=http://periyar.fm/admin/upload/audio_file/'.$row[2].' data-atitle="'.$row[3].'" onclick="playthis(this.id)">';
		
			}
			$eprint.=     
                '</div></div></div>
                
                            </div>
       
        </div>';
		}
		echo $eprint."<hr>";

}
}*/
include_once("connection.php");
$selectcategories="select Category_Id,Category_Name from category_manager where Status!=0";
$selectcategoriesexe=mysql_query($selectcategories);
if(!$selectcategories){
	echo mysql_error();
}
$count=mysql_num_rows($selectcategoriesexe);
if($count>0)
{
	
	while($row1=mysql_fetch_array($selectcategoriesexe,MYSQL_BOTH))
	{
		$select='select Distinct Audio_Id,Audio_Album,Audio_File,Audio_Title,Audio_Descript,Category_Name,am.Category_Id from audio_manager as am,category_manager as cm where am.Category_Id=cm.Category_Id and cm.Category_Id='.$row1["0"].' order by Audio_Id Desc Limit 0,12';
		$exe=mysql_query($select);
		if(!$exe)
		{
		echo mysql_error();
		}
		$cnt=mysql_num_rows($exe);
	
		if($cnt>0)
		{
			$eprint='';
			$eprint.='<meta charset="utf-8"><h4>'.$row1["1"].'</h4><span style="float:right;"><a href="?id='.$row1["0"].'">மேலும் பார்க்க</a></span>';
			  $eprint.='<div class="well">
            <div id="myCarousel" class="carousel slide">           
                <div class="carousel-inner">
				<div class="item active">
                   <div class="row">';
			while($row=mysql_fetch_array($exe,MYSQL_BOTH))
			{
				 $eprint.='<div class="col-sm-2"><img src="http://periyar.fm/admin/upload/image_file/'.$row[1].'" class="img-responsive thumbnail" id="'.$row[0].'"data-audio=http://periyar.fm/admin/upload/audio_file/'.$row[2].' data-atitle="'.$row[3].'" onclick="playthis(this.id)" style="cursor:pointer;"> 
                            </div>';
							//echo '<img src="http://periyar.fm/admin/upload/image_file/'.$row[1].'" class="img-responsive" id="'.$row[0].'"data-audio=http://periyar.fm/admin/upload/audio_file/'.$row[2].' data-atitle="'.$row[3].'" onclick="playthis(this.id)">';
		
			}
			$eprint.=     
                '</div></div></div>
                
                            </div>
       
        </div>';
		}
		echo $eprint."<hr>";
	}
}
				
?>



							
                            









