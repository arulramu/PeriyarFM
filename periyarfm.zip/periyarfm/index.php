<?php 	
include_once("templates/header.php");	
include_once("functions.php");	
$section = parse_ini_file("config.ini");	?>
<div id="leftcolumn"><!--<p>தந்தை பெரியார் சிலை திறப்பு விழா-17-09-2015</p>--><div><img src="images/news.jpg" width="250px" height="240" ></div><!--<textarea style="margin:10px 0px 0px 10px;padding-left:5px;width:210px;height:110px;background-color:#CCCCCC;">&lt;iframe src="http://www.goo.gl/aN1eQ" width="250px" height="100%" frameborder="0"&gt;&lt;/iframe&gt;</textarea>--><!--<iframe src="http://www.goo.gl/aN1eQ" width="250px" height="500px" frameborder="0">  <p>Your browser does not support iframes.</p></iframe>-->

<script>
  window.fbAsyncInit = function() {
    FB.init({
      appId      : '289308724740937',
      cookie     : true,
      xfbml      : true,
      version    : 'v7.0'
    });
      
    FB.AppEvents.logPageView();   
      
  };

  (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = "https://connect.facebook.net/en_US/sdk.js";
     fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));
</script>

<!--<script>  
window.fbAsyncInit = function() {    FB.init({      appId      : '289308724740937',      xfbml      : true,      version    : 'v2.6'    });  };  (function(d, s, id){     var js, fjs = d.getElementsByTagName(s)[0];     if (d.getElementById(id)) {return;}     js = d.createElement(s); js.id = id;     js.src = "//connect.facebook.net/en_US/sdk.js";     fjs.parentNode.insertBefore(js, fjs);   }(document, 'script', 'facebook-jssdk'));
</script>-->




<iframe src="playlist.php" width="250px" height="500px" frameborder="0">  <p>Your browser does not support iframes.</p></iframe></div><div id="content" style="padding:9px 4px 25px 4px;">	<!-- Accordion -->			<div id="accordion">							  				<div>					<h3><a href="#"><?php echo $section["TITLE_2"];?></a></h3>					<div><?php echo AudioDisplay(2,4); ?></div>				</div>								<div>					<h3><a href="#"><?php echo $section["TITLE_1"];?></a></h3>					 <div><?php echo AudioDisplay(1,4); ?></div>				</div>				
<div>					<h3><a href="#"><?php echo $section["TITLE_11"];?></a></h3>					<div><?php echo AudioDisplay(13,4); ?></div>				</div>	

<div>					<h3><a href="#"><?php echo $section["TITLE_12"];?></a></h3>					<div><?php echo AudioDisplay(14,4); ?></div>				</div>	


<div>					<h3><a href="#"><?php echo $section["TITLE_3"];?></a></h3>					<div><?php echo AudioDisplay(3,4); ?></div>				</div>			

			

<div>					<h3><a href="#"><?php echo $section["TITLE_4"];?></a></h3>					<div><?php echo AudioDisplay(4,4); ?></div>				</div>										<div>					<h3><a href="#"><?php echo $section["TITLE_5"];?></a></h3>					<div><?php echo AudioDisplay(5,4); ?></div>				</div>						<div>					<h3><a href="#"><?php echo $section["TITLE_6"];?></a></h3>					<div><?php echo AudioDisplay(6,4); ?></div>				</div>									<div>					<h3><a href="#"><?php echo $section["TITLE_9"];?></a></h3>					<div><?php echo AudioDisplay(9,4); ?></div>				</div>					<div>					<h3><a href="#"><?php echo $section["TITLE_10"];?></a></h3>					<div><?php echo AudioDisplay(11,4); ?></div>				</div>								


		

</div>			<p align="center">			<!-- Go to www.addthis.com/dashboard to customize your tools -->	<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5757a2ebc61fdf7e"></script>			<!--<a name="fb_share"></a> 				<script src="http://static.ak.fbcdn.net/connect.php/js/FB.Share" type="text/javascript"></script>-->			</p></div><?php include_once("templates/footer.php") ?>