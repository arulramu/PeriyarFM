<?php
if($_POST["Login"] == "Login"){
		if(($_POST["name"] == "periyarfm") && ($_POST["userpass"] == "Viduthalai")) {
			session_start();
			$_SESSION["TEMP_CHECK"] = time();
			header("Location:admin.php");
		} else {
			//$name = $_POST["name"];
			$message = "Please Enter Correct information";
		}
	}
?>
<script type="text/javascript">
	function validateFormOnSubmit(theForm) {
	var reason = "";

	  reason += validateUsername(theForm.name);
	  reason += validatePassword(theForm.userpass);
	 if (reason != "") {
		alert("Some fields need correction:\n" + reason);
		return false;
	  }

	  return true;
	}
	function validateUsername(fld) {
		var error = "";
		var illegalChars = /\W/; // allow letters, numbers, and underscores
	 
		if (fld.value == "") {
			fld.style.background = 'Yellow'; 
			error = "You didn't enter a username.\n";
		} else if ((fld.value.length < 5) || (fld.value.length > 15)) {
			fld.style.background = 'Yellow'; 
			error = "The username is the wrong length.\n";
		} else if (illegalChars.test(fld.value)) {
			fld.style.background = 'Yellow'; 
			error = "The username contains illegal characters.\n";
		} else {
			fld.style.background = 'White';
		}
		return error;
	}
	function validatePassword(fld) {
		var error = "";
		var illegalChars = /[\W_]/; // allow only letters and numbers 
	 
		if (fld.value == "") {
			fld.style.background = 'Yellow';
			error = "You didn't enter a password.\n";
		} else if ((fld.value.length < 7) || (fld.value.length > 15)) {
			error = "The password is the wrong length. \n";
			fld.style.background = 'Yellow';
		} else if (illegalChars.test(fld.value)) {
			error = "The password contains illegal characters.\n";
			fld.style.background = 'Yellow';
		} else if (!((fld.value.search(/(a-z)+/)) && (fld.value.search(/(0-9)+/)))) {
			error = "The password must contain at least one numeral.\n";
			fld.style.background = 'Yellow';
		} else {
			fld.style.background = 'White';
		}
	   return error;
	}   
</script>
<table align="center">
<tr>
<td>
<table style="border:solid;margin:140px;" width="270px" height="100px">
<div align="center"> <?php echo $message; ?></div>
<tr style="text-align:center;background-color:#DF781C;font-size:13px;color:white;">
<td colspan="2">Enter your Login Details</td>
</tr>
<tr>
<form name="usercheck" method="POST" action="index.php" onsubmit="return validateFormOnSubmit(this)">
<td>User Name: </td> <td><input type="text" name="name" value="<?php echo $name; ?>"/>
</tr>
<tr>
<td>Password : </td> <td><input type="password" name="userpass" /></td>
</tr>
<tr align="center">
<td colspan="2"><input type="submit" name="Login" value="Login"/></td>
</tr>
</form>
</table>
</td>
</tr>
</table>