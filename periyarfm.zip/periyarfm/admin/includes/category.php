<form id="form1" name="category" method="post" action="">
	<table width="300" border="0" align="center" class="show">
		<tr>
			<td>Cateogry Title</td>
			<td><label>
			<input type="text" name="cat_name" id="cat_name" />
			</label></td>
		</tr>
		<tr>
			<td><label>Publish</label></td>
			<td><input type="radio" name="publish" id="published" value="0" selected />
			No
			<input type="radio" name="publish" id="published" value="1"/>Yes</td>
		</tr>
		<tr>
			<td colspan="2"><div align="center">
			<input type="submit" name="submit" value="Submit"/>
			</td>
		</tr>
	</table>
</form>