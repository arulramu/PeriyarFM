<?php

Class FormDisplay {
	
	function Category() {
			
		$categ_display =
		'<br/><form id="form1" name="category" method="post" action="">
		<table width="300" border="0" align="center" class="show">
		<tr>
		<td>Cateogry Title</td>
		<td><label>
		<input type="text" name="cat_name" id="cat_name" />
		</label></td>
		</tr>
		<tr>
		<td><label>Publish</label></td>
		<td><input type="radio" name="publish" id="published" value="0" selected />
		No
		<input type="radio" name="publish" id="published" value="1"/>
		Yes</td>
		</tr>
		<tr>
		<td colspan="2"><div align="center">
		<input type="submit" name="submit" value="Submit"/>
		</div></td>
		</tr>
		</table>
		</form> ';
		return $categ_display;
	}
	
}
class MenuDisplay {
	var $action_var;
	function AEDfunc($action) {
		
		$this->action_var = $action;
			
		$aed_func = '<table border="1">
		<tr><td><a href="index.php?action='.$this->action_var.'&add='.$this->action_var.'"> ADD</a> </td><td><a href="index.php?cat'.$this->action.'"> EDIT <a/></td><td><a href="index.php?cat'.$this->action.'">Delete</a></td></tr></table>';
		echo $aed_func;
		exit;
		
	return $aed_func;
	}
}

?>