<?php
	function MYsqlFunction() {
		$db_host = "localhost";
		$db_user = "fm_periyarfm";
		$db_password = "4U0VIf4yAxm4";
		$db_database = "fm_periyarfm";
		
		$connect = mysql_connect($db_host,$db_user,$db_password) or die("Database Doesn't connect");
		$select = mysql_select_db($db_database,$connect) or die("Database doesn't Select");
		
		return $select;
	}		
?>