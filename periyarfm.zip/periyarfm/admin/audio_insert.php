<?php
	session_start();
	include_once("db/dbconnect.php");
	if($_POST["Audio_Submit"] == "Submit") {
		
		if(empty($_POST["title"]) ) {
			header('Location:admin.php?section=audio&action=showaudio&add=addaudio&msg=Enter Audio Title&'.'desc='.trim($_POST["description"]).'');
		}elseif(empty($_POST["description"])) {
			header('Location:admin.php?section=audio&action=showaudio&add=addaudio&msg=Enter Description&'.'title='.trim($_POST["title"]).'');
		}elseif(!$_FILES["audio_image"]["name"]) {
			header('Location:admin.php?section=audio&action=showaudio&add=addaudio&msg= Browse album Image&title='.$_POST["title"].'&desc='.trim($_POST["description"]).'');
		}elseif(!$_FILES["audio_file"]["name"]) {
			header('Location:admin.php?section=audio&action=showaudio&add=addaudio&msg= Browse album file&title='.$_POST["title"].'&desc='.trim($_POST["description"]).'&audiofile='.$_FILES["audio_image"]["name"].'');
		}
		if(MysqlFunction() == true) {
			$image_source_file_name = explode(".",basename($_FILES['audio_image']['name']));
			$allowedExts = array("gif", "jpeg", "jpg", "png");
			$extension = end(explode(".", $_FILES["audio_image"]["name"]));
			if ((($_FILES["audio_image"]["type"] == "image/gif")
				|| ($_FILES["audio_image"]["type"] == "image/jpeg")
					|| ($_FILES["audio_image"]["type"] == "image/jpg")
					|| ($_FILES["audio_image"]["type"] == "image/png"))&& in_array($extension, $allowedExts)){
	
						}
							else
							{
								header('Location:admin.php?section=audio&action=showaudio&add=addaudio&msg=Invalid Image Format &title='.trim($_POST["title"]).'&desc='.trim($_POST["description"]).'');
							exit;
							}	
				
				
							
				$audio_source_file_name = explode(".",basename($_FILES['audio_file']['name']));
				if(($audio_source_file_name[1])=="mp3" || ($audio_source_file_name[1]=="mpeg"))
				{
									
				}
				else{
					header('Location:admin.php?section=audio&action=showaudio&add=addaudio&msg= Invalid audio file format&title='.$_POST["title"].'&desc='.trim($_POST["description"]).'&audiofile='.$_FILES["audio_image"]["name"].'');
					exit;
				}
								
			$result1 = mysql_query("SELECT Audio_Id FROM audio_manager order by Audio_Id DESC LIMIT 1");
			$total_num1 = mysql_fetch_row($result1);
			$total_num = empty($total_num1[0])?1:$total_num1[0]+1;
			if (is_uploaded_file($_FILES['audio_image']['tmp_name']) && is_uploaded_file($_FILES['audio_file']['tmp_name'])) {
							
				$image_dest_file_name ="audio_image_".$total_num.".".$image_source_file_name[1] ;
				
				$audio_dest_file_name ="audio_file_".$total_num.".".$audio_source_file_name[1] ;
									
				$image_target = "upload/image_file/";
				$audio_target = "upload/audio_file/";
				$image_upload = move_uploaded_file($_FILES['audio_image']['tmp_name'],$image_target.$image_dest_file_name)? 1 : 0;
				$audio_upload = move_uploaded_file($_FILES['audio_file']['tmp_name'],$audio_target.$audio_dest_file_name)? 1 : 0;				
				if($image_upload == $audio_upload) {
					$query = "INSERT INTO `audio_manager` (`Audio_Id`, `Category_Id`, `Admin_Id`, `Audio_Title`, `Audio_Descript`, `Audio_Album`, `Audio_Date`, `Audio_File`, `Hits`, `Status`) VALUES (NULL, '".$_POST['category']."', '1', '".trim($_POST['title'])."', '".trim($_POST['description'])."', '".$image_dest_file_name."', '".DATE('Y-m-d h:m:s')."', '".$audio_dest_file_name."', '0','1');";
					
					$result = mysql_query($query);
					if($result == true) {
					header('Location:admin.php?section=audio&action=showaudio&add=addaudio&msg= file saved');
					} else {
					header('Location:admin.php?section=audio&action=showaudio&add=addaudio&msg= file not saved');
					}
				}else {
					header('Location:admin.php?section=audio&action=showaudio&add=addaudio&msg=file not uploaded');
				}			
				
			}else {
			header('Location:admin.php?section=audio&action=showaudio&add=addaudio&msg=Browse album file&title='.trim($_POST["title"]).'&desc='.trim($_POST["description"]).'');			
			}
			
					
		}
	}
?>