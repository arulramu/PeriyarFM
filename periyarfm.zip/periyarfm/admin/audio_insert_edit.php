<?php
	session_start();
	include_once("db/dbconnect.php");
	
	if($_POST["Audio_Submit"] == "Submit") {
		
		if(empty($_POST["title"]) ) {
			header('Location:index.php?section=audio&action=showaudio&add=addaudio&msg=Enter Audio Title&'.'desc='.$_POST["description"].'');
		}elseif(empty($_POST["description"])) {
			header('Location:index.php?section=audio&action=showaudio&add=addaudio&msg=Enter Description&'.'title='.$_POST["title"].'');
		}elseif(!$_FILES["audio_image"]["name"]) {
			header('Location:index.php?section=audio&action=showaudio&add=addaudio&msg= Browse album Image&title='.$_POST["title"].'&desc='.$_POST["description"].'');
		}elseif(!$_FILES["audio_file"]["name"]) {
			header('Location:index.php?section=audio&action=showaudio&add=addaudio&msg= Browse album file&title='.$_POST["title"].'&desc='.$_POST["description"].'&audiofile='.$_FILES["audio_image"]["name"].'');
		}
		if(MysqlFunction() == true) {
			$result = mysql_query("SELECT * FROM audio_manager");
			$total_num = mysql_num_rows($result);
			$totalnum ++;
			if (is_uploaded_file($_FILES['audio_image']['tmp_name']) && is_uploaded_file($_FILES['audio_file']['tmp_name'])) {
				$image_source_file_name = explode(".",basename($_FILES['audio_image']['name']));
				$image_dest_file_name ="audio_image_".$totalnum.".".$image_source_file_name[1] ;
				$audio_source_file_name = explode(".",basename($_FILES['audio_file']['name']));
				$audio_dest_file_name ="audio_file_".$totalnum.".".$audio_source_file_name[1] ;
							
				$image_target = "upload/image_file/";
				$audio_target = "upload/audio_file/";
				$image_upload = move_uploaded_file($_FILES['audio_image']['tmp_name'],$image_target.$image_dest_file_name)? 1 : 0;
				$audio_upload = move_uploaded_file($_FILES['audio_file']['tmp_name'],$audio_target.$audio_dest_file_name)? 1 : 0;
				if($image_upload == $audio_upload) {
					$query = "INSERT INTO `audio_manager` (`Audio_Id`, `Category_Id`, `Admin_Id`, `Audio_Title`, `Audio_Descript`, `Audio_Album`, `Audio_Date`, `Audio_File`, `Hits`, `Status`) VALUES (NULL, '".$_POST['category']."', '1', '".trim($_POST['title'])."', '".trim($_POST['description'])."', '".$image_dest_file_name."', '".DATE('Y-m-d h:m:s')."', '".$audio_dest_file_name."', '0','1');";
					
					$result = mysql_query($query);
					if($result == true) {
					header('Location:index.php?section=audio&action=showaudio&add=addaudio&msg= file saved');
					} else {
					header('Location:index.php?section=audio&action=showaudio&add=addaudio&msg= file not saved');
					}
				}else {
					header('Location:index.php?section=audio&action=showaudio&add=addaudio&msg=file not uploaded');
				}			
				
			}else {
				header('Location:index.php?section=audio&action=showaudio&add=addaudio&msg= Browse album file&title='.$_POST["title"].'&desc='.$_POST["description"].'');			
			}
					
		}
	}
?>