<?php
	session_start();
	include_once("includes/functions.php");
	include_once("db/dbconnect.php");
	MysqlFunction();
	$del_query = "DELETE FROM audio_manager WHERE Audio_Id='".$_GET["id"]."'";
	if(mysql_query($del_query)){
		echo "DELETED";
	}else {
		echo "THE RECORD DID NOT REMOVE";
	}	
?>