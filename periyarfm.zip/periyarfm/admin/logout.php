<?php
	session_start();
	session_destroy();
	unset($_SESSION["TEMP_CHECK"]);
	header("Location:index.php");
?>