<?php
$con=mysql_connect("localhost","fm_periyarfm","4U0VIf4yAxm4");
// mysql_set_charset(utf8,$con);
// mysql_query ("set character_set_client='utf8'"); 
// mysql_query ("set character_set_results='utf8'"); 
// mysql_query ("set collation_connection='utf8_general_ci'"); 
if(!$con)
echo mysql_error()."<br>";
$db=mysql_select_db('fm_periyarfm',$con);
if(!$db){
echo mysql_error()."<br>";
}
?>