<?php
session_start();
include_once("templates/header.php");
include_once("includes/functions.php");
include_once("db/dbconnect.php");
echo '<p align="center"><strong><a href="http://periyar.fm/admin/admin.php?section=category"><img src="templates/images/back_button.png"/></a></strong></p>';

if($_GET["action"]=="edit"){
		
		if(MysqlFunction()==true){
			$query = "SELECT * FROM category_manager where Category_Id=".$_GET["cat_id"];
			$result = mysql_query($query);			
			$disp_result = mysql_fetch_row($result);			
			
		$categ_display = '<br/><form id="form1" name="category" method="post" action="'.$_SERVER['PHP_SELF'].'?cat_id='.$_GET["cat_id"].'&status=update">
		<table width="300" border="0" align="center" class="show">
		<tr>
		<td>Cateogry Title</td>
		<td><label>
		<input type="text" name="cat_name" id="cat_name" value="'.$disp_result[1].'"/>
		</label></td>
		</tr>
		<tr>
		<td><label>Publish</label></td>
		<td><input type="radio" name="publish" id="published" value="0"';
		if($disp_result[3] == 0){
		$categ_display .= 'checked="checked"';
		}
		$categ_display .='/>No
		<input type="radio" name="publish" id="published" value="1"';
		if($disp_result[3] == 1){
		$categ_display .= 'checked="checked"';
		}
		$categ_display .='/>		
		Yes</td>
		</tr>
		<tr>
		<td colspan="2"><div align="center">
		<input type="submit" name="submit" value="Submit"/>
		</div></td>
		</tr>
		</table>
		</form> ';
		echo $categ_display."</br>";		
		}else {
			echo "Not Available ";
		}		
	} elseif($_GET["status"] == "update"){
		if(MysqlFunction() == true) {
				if(!empty($_GET["cat_id"])) {
				$result = mysql_query("SELECT * FROM category_manager");
				$total_num = mysql_num_rows($result);
				$total_num ++ ;
				$query = "UPDATE category_manager SET `Category_Name`='".$_POST["cat_name"]."',`Status`='".$_POST["publish"]."' WHERE `Category_Id`='".$_GET["cat_id"]."'";
				$insert_result = mysql_query($query);
					if($insert_result == true){
						$message = "Added";
					} else {
						$message = "There is Error";
					}
				}
				$message = "Please Enter The Category Name ";
			}
	} elseif($_GET["action"] == "delete") {
		if(MysqlFunction() == true) {
				if(!empty($_GET["cat_id"])) {
				$result = mysql_query("SELECT * FROM category_manager");
				$total_num = mysql_num_rows($result);
				$total_num ++ ;
				$query = "DELETE FROM category_manager WHERE `Category_Id`='".$_GET["cat_id"]."'";
				$insert_result = mysql_query($query);
					if($insert_result == true){
						$message = "DELETED";
					} else {
						$message = "There is Error";
					}
				}
				$message = "Please select category id ";
				echo "Deleted";
			}
		
	}
include_once("templates/footer.php");
?>