<?php
	session_start();
	include_once("templates/header.php");
	include_once("includes/functions.php");
	include_once("db/dbconnect.php");
	
	/*JSON FIle Creation Dynamically apple store 22-08-2016*/
include "connection.php";
$selectcategories="select Category_Id,Category_Name from category_manager where Status!=0";
$selectcategoriesexe=mysql_query($selectcategories);
if(!$selectcategories){
	echo mysql_error();
}
$count=mysql_num_rows($selectcategoriesexe);


if($count>0)
{
	$categories=array();
	while($row1=mysql_fetch_array($selectcategoriesexe,MYSQL_BOTH))
	{
	//$select="select Distinct Audio_Id,Audio_Album,Audio_File,Audio_Title,Audio_Descript,Category_Name,am.Category_Id from audio_manager as am,category_manager as cm where am.Category_Id=cm.Category_Id and cm.Category_Id='$i' order by Audio_Id ASC";
	$select='select Distinct am.Audio_Id,am.Audio_Album,am.Audio_File,am.Audio_Title,am.Audio_Descript,cm.Category_Name,am.Category_Id from audio_manager as am,category_manager as cm where am.Category_Id=cm.Category_Id and cm.Category_Id='.$row1["0"].' order by am.Audio_Id Desc';
		$exe=mysql_query($select);
		if(!$exe)
		{
		echo mysql_error();
		}
		$cnt=0;
		$cnt=mysql_num_rows($exe);		
		if($cnt>0)
		{
			//$id1='array("categoryId"=>"'.$i.'","CategoryItems"=>array(';
		$id=array();

			while($row=mysql_fetch_array($exe,MYSQL_BOTH))
			{
				$ch=explode(".",$row[1]);
				$au=explode(".",$row[2]);
				if(($ch["1"]=="png" || $ch["1"]=="gif" || $ch["1"]=="jpeg" || $ch["1"]=="jpg") & ($au["1"]=="mp3"||$au["1"]=="mpeg"))
				{
				$id[]=array("aid"=>$row[0],"pic"=>"admin/upload/image_file/".$row[1],"soundFile"=>"admin/upload/audio_file/".$row[2],"title"=>trim($row[3]),"description"=>trim($row[4]),"categoryId"=>$row[6],"category"=>$row[5]);
				arsort($id);
				}
			}
			
			$categories[]=array("categoryId"=>"$row1[0]","categoryItems"=>$id);
		}

	}
	



}

$fp = fopen('results.json', 'w');
fwrite($fp, json_encode($categories));
fclose($fp);
/*$androidfm=fopen('fm.json', 'w');
fwrite($androidfm, json_encode($categories));
fclose($androidfm);*/

/*JSON FIle Creation Dynamically apple store 22-08-2016 End*/
/*test*/

if(isset($_POST["get"])){
$select="select Distinct Audio_Id,Audio_Album,Audio_File,Audio_Title,Audio_Descript,Category_Name,am.Category_Id from audio_manager as am,category_manager as cm where am.Category_Id=cm.Category_Id and cm.Category_Id='2' order by Audio_Id ASC";
		$exe=mysql_query($select);
		if(!$exe)
		{
		echo mysql_error();
		}
		$cnt=mysql_num_rows($exe);
		if($cnt>0)
		{
			
			/*$id=array();

			while($row=mysql_fetch_array($exe,MYSQL_BOTH))
			{
				$ch=explode(".",$row[1]);
				$au=explode(".",$row[2]);
				if(($ch["1"]=="png" || $ch["1"]=="gif" || $ch["1"]=="jpeg" || $ch["1"]=="jpg") & ($au["1"]=="mp3"))
				{
				$id[]=array("aid"=>$row[0],"pic"=>"admin/upload/image_file/".$row[1],"soundFile"=>"admin/upload/audio_file/".$row[2],"title"=>trim($row[3]),"description"=>trim($row[4]),"categoryId"=>$row[6],"category"=>$row[5]);
				}
			}
			
			$categories[]=array("categoryId"=>"$i","categoryItems"=>$id);*/
			$result = array();
			while($row=mysql_fetch_array($exe,MYSQL_BOTH))
			{
			array_push($result,array("aid"=>$row[0],"pic"=>"admin/upload/image_file/".$row[1],"soundFile"=>"admin/upload/audio_file/".$row[2],"title"=>trim($row[3]),"description"=>trim($row[4]),"categoryId"=>$row[6],"category"=>$row[5]));
			}
		}
echo json_encode(array("result"=>$result));

}




//include_once("includes/clsUpload.php");
	 $message = $_GET["msg"];
?>
<div id="mainContent">
<?php
	if($_POST["submit"] == "Submit") {
			if(MysqlFunction() == true) {
				if(!empty($_POST["cat_name"])) {
				$result = mysql_query("SELECT * FROM category_manager");
				$total_num = mysql_num_rows($result);
				$total_num ++ ;
				$query = "INSERT INTO category_manager(`Category_Id`,`Category_Name`,`Order_No`,`Status`)VALUES (NULL ,'".$_POST["cat_name"]."','".$total_num."',".$_POST["publish"].")";
				$insert_result = mysql_query($query);
					if($insert_result == true){
						$message = "Added";
					} else {
						$message = "There is Error";
					}
				}else {
				$message = "Please Enter The Category Name ";
				}
			}
	}
?>
	
	<table border="1" align="center">
		<tr>
		<td colspan="2"><a href="admin.php?section=category"><img src="templates/images/cate_button.png"/></a></td><td><a href="admin.php?section=audio"> <img src="templates/images/audio_button.png"/> <a/></td>
		</tr>
		<?php 
		if($_GET["section"] == "category") {
		?>
		<tr align="center"><td colspan="3" ><a href="admin.php?section=category&action=showcat&add=addcat"> <img src="templates/images/add_button.png"/></a> </td></tr>
		<?php } ?>
		<?php 
		if($_GET["section"] == "audio") {
		?>
		<tr align="center">
		<td colspan="3">
		<a href="admin.php?section=audio&action=showaudio&add=addaudio"> <img src="templates/images/add_button.png"/></a> </td>		</tr>
		<?php } ?>
		
	</table>
	<div align="center" style="color:red;font-size:12px;" id="message"><?php echo $message; ?></div>
</div>
<?php
	if(($_GET["section"]== "audio")&&(!$_GET["action"] == "showaudio")){
		include("audio_display.php");
	}
	if(($_GET["section"]== "category")&&(!$_GET["action"] == "showcat")){
		include("audio_category.php");
	}
	
	if(($_GET["action"]=="showcat") &&($_GET["add"]=="addcat")){
		$categ_display =
		'<br/><form id="form1" name="category" method="post" action="'.$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'].'">
		<table width="300" border="0" align="center" class="show">
		<tr>
		<td>Cateogry Name</td>
		<td><label>
		<input type="text" name="cat_name" id="cat_name" />
		</label></td>
		</tr>
		<tr>
		<td><label>Publish</label></td>
		<td><input type="radio" name="publish" id="published" value="0"/>
		No
		<input type="radio" name="publish" id="published" value="1" checked="checked"/>
		Yes</td>
		</tr>
		<tr>
		<td colspan="2"><div align="center">
		<input type="submit" name="submit" value="Submit"/>
		</div></td>
		</tr>
		</table>
		</form> ';
		echo $categ_display."</br>";		
	} elseif(($_GET["action"]=="showaudio") &&($_GET["add"]=="addaudio")) {
		MysqlFunction();
		$result = mysql_query("SELECT * FROM category_manager");
		$audio_display = '
		<form id="form1" name="category" method="post" action="audio_insert.php" enctype="multipart/form-data" >
		<table width="409" border="0" align="center" class="show"><tr><td>
		Category</td><td> <select name="category" style="width:220px;" required><option value="" selected> Select </option>';
		while($disp = mysql_fetch_array($result)){
			$audio_display .='<option value="'.$disp["Category_Id"].'">'.$disp["Category_Name"]."</option>";
		}
		//$audi_display = 
			
		$audio_display .='</td></select>
						</tr><tr>
						<td width="120">Audio Titile</td>
						<td width="498">
						<label>
						<input type="text" name="title" id="title" style="width:220px;" value="'.$_GET["title"].'"/>
						</label>
						</td>
						</tr>
						<tr>
						<td>Description</td>
						<td><label>
						<textarea name="description" id="description" cols="45" rows="5" style="width:220px;">'.$_GET["desc"].'</textarea>
						</label></td>
						</tr>
						<tr>
						<td>Image</td>
						<td><label>
						<input type="file" name="audio_image" id="image" value="'.$_GET["audiofile"].'" />
						</label></td>
						</tr>
						<tr>
						<td>Audio File</td>
						<td><label>
						<input type="file" name="audio_file" id="audio_file" />
						</label></td>
						</tr>
						<tr align="center"><td colspan="2"><input type="submit" name="Audio_Submit" value="Submit"/></td></tr>
						</table></form>';
		echo $audio_display;
	} 
	include_once("templates/footer.php");
?>