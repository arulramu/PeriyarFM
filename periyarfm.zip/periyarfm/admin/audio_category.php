<?php
	session_start();
	if(MysqlFunction() == true) {
		
		$query = "SELECT * FROM category_manager";
		$execu_result = mysql_query($query);
		if($execu_result){
			echo '<table align="center" style="font-size:12px;" border="1">';
			echo '<tr><th>ID.No:</th><th>Category Name</th><th colspan="2">Action </th></tr>';
			while($result = mysql_fetch_object($execu_result)) {
				echo '<tr><td>'.$result->Category_Id.'</td><td>'.$result->Category_Name.'</td><td style="background-color:orange;color:white;"><a href="category_edit.php?action=edit&cat_id='.$result->Category_Id.'" title="Category Edit" class="audio_edit" >Edit</a></td><td style="background-color:red;color:white;"><!--<a href="category_edit.php?action=delete&cat_id='.$result->Category_Id.'">-->Delete<!-- </a> --></td></tr></tr>';
			}
			echo'</table>';
		}
	}	

?>