<?php
	session_start();
	if($_SESSION["TEMP_CHECK"]){
	} else {
	header("Location:index.php");
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="javascript" href="http://code.jquery.com/jquery-1.6.2.js" type="text/script"/>
<link rel="stylesheet" href="css/template.css" type="text/css"/>
<style type="text/css">
table, td, th
{
border:1px solid green;
}
th
{
background-color:green;
color:white;
}
a:link {color:#FFFFFF;text-decoration:none;}      /* unvisited link */
a:visited {color:blue;text-decoration:none;}  /* visited link */
a:hover {color:#0000FF; text-decoration:none;}  /* mouse over link */
a:active {color:red; text-decoration:none;}  /* selected link */

</style>
<script type="text/javascript"> 
$('.audio_edit').popupWindow({centerScreen:1}); 
</script>
<title>PERIYAR AUDIO FM</title>
</head>
<body class="oneColLiqCtrHdr">
<div id="container">
<div id="header">
<h3>PERIYAR AUDIO FM</h3>
<div align="right"><a href="logout.php"> Logout </a></div>
</div>