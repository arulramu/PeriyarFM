<script type="text/javascript">
function EditFunction(audio_id) {
		window.open("audio_edit.php?audio_id="+audio_id);
	}
function DelFunction(audio_id){
	if (window.XMLHttpRequest)
		{// code for IE7+, Firefox, Chrome, Opera, Safari
			xmlhttp=new XMLHttpRequest();
		}
	else
		{// code for IE6, IE5
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		}
	xmlhttp.onreadystatechange=function(){
		if (xmlhttp.readyState==4 && xmlhttp.status==200)
		{
			document.getElementById("message").innerHTML =  xmlhttp.responseText;
			window.location.reload(false);
		}
	}
	xmlhttp.open("GET","audio_del.php?id="+audio_id,true);
	alert(audio_id);
	xmlhttp.send();
}
</script>
<?php
	session_start();
	if(MysqlFunction() == true) {
		$query = "SELECT * FROM audio_manager ORDER BY Audio_Id DESC";
		$execu_result = mysql_query($query);
		if($execu_result){
			echo '<table align="center" style="font-size:12px;">';
			echo '<tr align="center"><th>ID.No:</th><th>Category</th><th>Audio Title</th><th>Description</th><th colspan="3">Action</th></tr>';
			while($result = mysql_fetch_object($execu_result)) {
				echo '<tr><td>'.$result->Audio_Id.'</td><td>'.GetCatName($result->Category_Id).'</td><td>'.$result->Audio_Title.'</td><td>'.$result->Audio_Descript.'</td><td style="background-color:orange;color:white;"><span onclick="EditFunction(\''.$result->Audio_Id.'\')">Edit</span></td><td style="background-color:red;color:white;"><span onclick="DelFunction(\''.$result->Audio_Id.'\')">Delete</span></td></tr>';
			}
			echo'</table>';
		}
	$select="select Distinct Audio_Album,Audio_File,Audio_Title,Audio_Descript from audio_manager";//pic,soundFile,title,description
		$exe=mysql_query($select);
		if(!$exe)
			{
	echo mysql_error();
				}
			$arry='array(';
		$print="[";
			while($row=mysql_fetch_array($exe,MYSQL_BOTH))
		{
			$ch=explode(".",$row[0]);
			$au=explode(".",$row[1]);
	
			if(($ch["1"]=="png" || $ch["1"]=="gif" || $ch["1"]=="jpeg" || $ch["1"]=="jpg") & ($au["1"]=="mp3"))
		{

		$print.='{"pic":"admin/upload/image_file/'.$row[0].'","soundFile":"admin/upload/audio_file/'.$row[1].'","title":"'.$row[2].'","description":"'.$row[3].'"},<br>';
	$arry.='{"pic":"admin/upload/image_file/'.$row[0].'","soundFile":"admin/upload/audio_file/'.$row[1].'","title":"'.$row[2].'","description":"'.$row[3].'"},';
		}
			}
$print.="]";
//echo $print;
	}
	
	function GetCatName($cat_id){
		MysqlFunction();
		$query = "SELECT Category_Name FROM category_manager where Category_Id='".$cat_id."'";
		$result = mysql_query($query);
		$return_result = mysql_fetch_row($result);
		return $return_result[0];
	}

?>