<?php
	session_start();
	include_once("templates/header.php");
	include_once("includes/functions.php");
	include_once("db/dbconnect.php");
	//include_once("includes/clsUpload.php");
	 $message = $_GET["msg"];
	 

	// Audio Edit Option
		MysqlFunction();
		$audio_result = mysql_query("SELECT * FROM audio_manager where Audio_Id='".$_GET["audio_id"]."'");
		$audio_disp = mysql_fetch_object($audio_result);
		$result = mysql_query("SELECT * FROM category_manager");
		$audio_display = '
		<form id="form1" name="category" method="post" action="audio_edit.php?audio_id='.$_GET["audio_id"].'" enctype="multipart/form-data" >
		<table width="409" border="0" align="center" class="show"><tr><td>
		Category</td><td> <select name="category" style="width:220px;"><option value="" selected> Select </option>';
		while($disp = mysql_fetch_array($result)){
			$audio_display .='<option value="'.$disp["Category_Id"].'"';
			if($audio_disp->Category_Id == $disp["Category_Id"]){
				$audio_display .= '  selected="selected" ';
			}
			$audio_display .='>'.$disp["Category_Name"]."</option>";
		}
		//$audi_display = 
			
		$audio_display .='</td></select>
						</tr><tr>
						<td width="120">Audio Titile</td>
						<td width="498">
						<label>
						<input type="text" name="title" id="title" style="width:220px;" value="'.$audio_disp->Audio_Title.'"/>
						</label>
						</td>
						</tr>
						<tr>
						<td>Description</td>
						<td><label>
						<textarea name="description" id="description" cols="45" rows="5" style="width:220px;">'.$audio_disp->Audio_Descript.'</textarea>
						</label></td>
						</tr>
						<tr>
						<td>Image</td>
						<td><label>
						<input type="file" name="audio_image" id="image" value="'.$audio_disp->Audio_Album.'" />
						</label></td>
						</tr>
						<tr>
						<td>Audio File</td>
						<td><label>
						<input type="file" name="audio_file" id="audio_file" />
						</label></td>
						</tr>
						<tr align="center"><td colspan="2"><input type="submit" name="Audio_Edit_Submit" value="Submit"/></td></tr>
						</table></form>';
		echo $audio_display;
	
	if($_POST["Audio_Edit_Submit"]) {
		if(MysqlFunction() == true) {
			if (is_uploaded_file($_FILES['audio_image']['tmp_name']) && is_uploaded_file($_FILES['audio_file']['tmp_name'])) {
				$image_source_file_name = explode(".",basename($_FILES['audio_image']['name']));
				$image_dest_file_name ="audio_image_".$_GET["audio_id"].".".$image_source_file_name[1] ;
				$audio_source_file_name = explode(".",basename($_FILES['audio_file']['name']));
				$audio_dest_file_name ="audio_file_".$_GET["audio_id"].".".$audio_source_file_name[1] ;
							
				$image_target = "upload/image_file/";
				$audio_target = "upload/audio_file/";
				$image_upload = move_uploaded_file($_FILES['audio_image']['tmp_name'],$image_target.$image_dest_file_name)? 1 : 0;
				$audio_upload = move_uploaded_file($_FILES['audio_file']['tmp_name'],$audio_target.$audio_dest_file_name)? 1 : 0;		
				if(($image_upload == 1) || ($audio_upload == 1)) {
					//echo "eeee";
					$query = "UPDATE `audio_manager` SET `Category_Id` = '".$_POST['category']."',`Audio_Title`='".$_POST['title']."', `Audio_Descript`='".$_POST['description']."', `Audio_Album`='".$image_dest_file_name."', `Audio_Date`='".DATE('Y-m-d h:m:s')."', `Audio_File`='".$audio_dest_file_name."' WHERE Audio_Id='".$_GET["audio_id"]."'";
					$result = mysql_query($query);
					if($result == true) {
						echo "<script> if(confirm('Updated...Do you close this?')) {window.close();}else{}</script>";
					} else {
						echo "<script>javascript:alert('file not update')</script>";
					}
				}else {
					echo "<script>javascript:alert('image not update')</script>";
				}			
				
			}else {
				$query = "UPDATE `audio_manager` SET `Category_Id` = '".$_POST['category']."',`Audio_Title`='".$_POST['title']."', `Audio_Descript`='".$_POST['description']."',`Audio_Date`='".DATE('Y-m-d h:m:s')."' WHERE Audio_Id='".$_GET["audio_id"]."'";
					
				$result = mysql_query($query);	
					if($result == true) {
						echo "<script> if(confirm('Updated...Do you close this?')) {window.close();}else{}</script>";
					} else {
						echo "<script>javascript:alert('file not update')</script>";
					}
			}
					
		}
	} 
	include_once("templates/footer.php");


?>