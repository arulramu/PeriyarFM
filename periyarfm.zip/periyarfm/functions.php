<?php
include_once("admin/db/dbconnect.php");
function AudioDisplay($cat_id,$limit) {
	if(MysqlFunction()==true){
		$query = "SELECT * FROM audio_manager where Category_Id = ".$cat_id." ORDER BY Audio_Id DESC LIMIT 0,".$limit;
		$execu_result = mysql_query($query);			
			$disp = "<table class='gridtable' width=\"80px\"> <tr align=\"center\">";
			$no = 1;
		while($result = mysql_fetch_array($execu_result,MYSQL_BOTH)){	
			extract($result);
			/*$Audio_Album=$result["5"];
			$Audio_Descript=$result["4"];
			$Audio_Title=$result["3"];
			$Audio_File=$result["7"];*/
			$disp .='
				<td><a href="#" class="tip_trigger"><img src="admin/upload/image_file/'.$Audio_Album.'" width="80px" height="80px"/></br><span class="tip" style="display:none;">'.$Audio_Descript.'</span></a>'.$Audio_Title.'
				</br>
				<audio controls style="width:165px;">
	<source src="admin/upload/audio_file/'.$Audio_File.'" type="audio/mpeg">
	</audio><div class="fb-like" data-href="http://periyar.fm/player.php?audioid='.$Audio_Id.'&t='.$Audio_Descript.'"  data-layout="button_count" data-action="like" data-show-faces="false" data-share="false"></div><a class="addthis_counter addthis_pill_style"></a><script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5757a2ebc61fdf7e"></script>
				</td>';
				$no++;
		}
		$disp .='</tr><tr align="center"><td colspan="10"><span><a href="archieves.php?catid='.$cat_id.'">முந்தைய பதிவுகளை கேட்க</a></span></td></tr></table></br>';
		return $disp;
	}
	
}
function AudioPlay($audio_id){
	if(MysqlFunction()==true){
		$query = "SELECT * FROM audio_manager where Audio_Id = ".$audio_id;
		
		$execu_result = mysql_query($query);			
			$disp["disp"] = "<table class='gridtable' width=\"80px\"> <tr align=\"center\">";
			$no = 1;
		$result = mysql_fetch_array($execu_result);
			extract($result);
			$disp["disp"] .='
				<td><a href="#" class="tip_trigger"><img src="admin/upload/image_file/'.$Audio_Album.'" width="80px" height="80px"/></br><span class="tip" style="display:none;">'.$Audio_Descript.'</span></a>'.$Audio_Title.'
				</br>
				<p id="audioplayer_'.$cat_id.$no.'">No File</p>  
				<script type="text/javascript">  
				AudioPlayer.embed("audioplayer_'.$cat_id.$no.'", {soundFile: "admin/upload/audio_file/'.$Audio_File.'",width:150});  
				</script></td>';
		$disp["disp"] .='</tr></table></br>';		
		}
		$disp["meta"] .= $Audio_Descript;
		return $disp;
		
}
function ArchieveAudioDisplay($cat_id,$limit) {
	if(MysqlFunction()==true){
		$query = "SELECT * FROM audio_manager where Category_Id = ".$cat_id." ORDER BY Audio_Id DESC LIMIT ".$limit;
		$execu_result = mysql_query($query);			
			$disp = "<table class='gridtable' width=\"80px\"> <tr align=\"center\">";
			$no = 1;
			$cat_no = 1;
		while($result = mysql_fetch_array($execu_result)){
			
			extract($result);
			if($no == 1) {
					$disp .='<tr>';
				}
			$disp .='
				<td><img src="admin/upload/image_file/'.$Audio_Album.'" width="80px" height="80px"/></br>'.$Audio_Title.'
				<!--<td>'.$Audio_Descript.'</td> -->
				</br><audio controls style="width:165px;">
	<source src="admin/upload/audio_file/'.$Audio_File.'" type="audio/mpeg">
	</audio>
				<div class="fb-like" data-href="http://periyar.fm/player.php?audioid='.$Audio_Id.'&t='.$Audio_Descript.'" data-layout="button_count" data-action="like" data-show-faces="false" data-share="false"></div><a class="addthis_counter addthis_pill_style"></a><script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5757a2ebc61fdf7e"></script></td>';
				$cat_no ++ ;
				if($no == 4) {
					$disp .='</tr>';
					$no = 0;
				}
				$no++;
		}
		$disp .='</table></br>';
		return $disp;
	}
	
}
function FetchJscript($cat_id,$limit) {
	if(MysqlFunction()==true){
		$query = "SELECT * FROM audio_manager where Category_Id = ".$cat_id." ORDER BY Audio_Id DESC LIMIT 0,".$limit;
		$execu_result = mysql_query($query);			
		while($result = mysql_fetch_array($execu_result)){
			extract($result);
			$disp .='{name:"'.$Audio_Title.'", free:true,mp3:"'.'admin/upload/audio_file/'.$Audio_File.'"},';
		}		
		return $disp;
	}
		
}

function FetchJscriptNew() {
	if(MysqlFunction()==true){	
		//$query = "SELECT * FROM(SELECT * FROM audio_manager ORDER BY Audio_Id DESC) as nv WHERE Category_Id>1 GROUP BY Category_Id LIMIT 0,6";
		$query = "SELECT * FROM audio_manager ORDER BY Audio_Id DESC LIMIT 0,6";//arul
		$execu_result = mysql_query($query);			
		while($result = mysql_fetch_array($execu_result)){
			extract($result);
			$disp .='{name:"'.$Audio_Title.'", free:true,mp3:"'.'admin/upload/audio_file/'.$Audio_File.'"},';
		}		
		return $disp;
	}
		
}

function GetCatname($cat_id){
	if(MysqlFunction()==true){
		$query = "SELECT Category_Name FROM category_manager where Category_Id=".$cat_id."";
		$execu_result = mysql_query($query);
		$result = mysql_fetch_row($execu_result);
		return $result[0];
	}
}

?>