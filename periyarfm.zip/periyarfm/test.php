<?php
//include "/admin/connection.php";
include_once("connection.php");

/*if(isset($_POST["username"])&&isset($_POST["password"])){
	
	echo $_POST["username"]."  -> ".$_POST["password"];
	
}

else
{
	echo "failed".$_POST["username"];
}
*/
$selectcategories="select Category_Id,Category_Name from category_manager where Status!=0";
$selectcategoriesexe=mysql_query($selectcategories);
if(!$selectcategories){
	echo mysql_error();
}
$count=mysql_num_rows($selectcategoriesexe);

if($count>0)
{
$categories=array();
while($row1=mysql_fetch_array($selectcategoriesexe,MYSQL_BOTH))
	{
	$select='select Distinct am.Audio_Id,am.Audio_Album,am.Audio_File,am.Audio_Title,am.Audio_Descript,cm.Category_Name,am.Category_Id from audio_manager as am,category_manager as cm where am.Category_Id=cm.Category_Id and cm.Category_Id='.$row1["0"].' order by Audio_Id Desc limit 0,10';
		$exe=mysql_query($select);
		if(!$exe)
		{
		echo mysql_error();
		}
		$cnt=mysql_num_rows($exe);
		if($cnt>0)
		{
		
		$id=array();

			while($row=mysql_fetch_array($exe,MYSQL_BOTH))
			{
				$ch=explode(".",$row[1]);
				$au=explode(".",$row[2]);
				if(($ch["1"]=="png" || $ch["1"]=="gif" || $ch["1"]=="jpeg" || $ch["1"]=="jpg") & ($au["1"]=="mp3"))
				{
				$id[]=array("aid"=>$row[0],"pic"=>"http://periyar.fm/admin/upload/image_file/".$row[1],"soundFile"=>"http://periyar.fm/admin/upload/audio_file/".$row[2],"title"=>trim($row[3]),"description"=>trim($row[4]),"categoryId"=>$row[6],"category"=>$row[5]);
				}
			}
			
			$categories[]=array("categoryId"=>"$row1[0]","categoryItems"=>$id);
		}

}
}
echo json_encode($categories);
/*$selectcategories="select Category_Id,Category_Name from category_manager where Status!=0";
$selectcategoriesexe=mysql_query($selectcategories);
if(!$selectcategories){
	echo mysql_error();
}
$count=mysql_num_rows($selectcategoriesexe);


if($count>0)
{
	
	while($row1=mysql_fetch_array($selectcategoriesexe,MYSQL_BOTH))
	{
	$select='select Distinct am.Audio_Id,am.Audio_Album,am.Audio_File,am.Audio_Title,am.Audio_Descript,cm.Category_Name,am.Category_Id from audio_manager as am,category_manager as cm where am.Category_Id=cm.Category_Id and cm.Category_Id='.$row1["0"].' order by Audio_Id ASC';
		$exe=mysql_query($select);
		if(!$exe)
		{
		echo mysql_error();
		}
		$cnt=0;
		$cnt=mysql_num_rows($exe);		
		if($cnt>0)
		{
		$categories=array();
		$id=array();

			while($row=mysql_fetch_array($exe,MYSQL_BOTH))
			{
				$ch=explode(".",$row[1]);
				$au=explode(".",$row[2]);
				if(($ch["1"]=="png" || $ch["1"]=="gif" || $ch["1"]=="jpeg" || $ch["1"]=="jpg") & ($au["1"]=="mp3"))
				{
				$id[]=array("aid"=>$row[0],"pic"=>"admin/upload/image_file/".$row[1],"soundFile"=>"admin/upload/audio_file/".$row[2],"title"=>trim($row[3]),"description"=>trim($row[4]),"categoryId"=>$row[6],"category"=>$row[5]);
				}
			}
			
			$categories[]=array("categoryId"=>"$row1[0]","categoryItems"=>$id);
		}

	}
	



}*/


?>