<?php 
	include_once("templates/header.php");
	include_once("functions.php");
	$section = parse_ini_file("config.ini");	
?>
<!--<img src="images/viduthalaicallertunes.jpg" width="948" height="90" />
<div id="leftcolumn">
<textarea style="margin:10px 0px 0px 10px;padding-left:5px;width:210px;background-color:#CCCCCC;">
&lt;iframe src="http://www.goo.gl/aN1eQ" width="250px" height="100%" frameborder="0"&gt;
&lt;/iframe&gt;
</textarea>
<iframe src="http://www.goo.gl/vnuw3" width="250px" height="100%" frameborder="0">
  <p>Your browser does not support iframes.</p>
</iframe>

</div>-->

<div id="content" style="padding:9px 4px 25px 4px;">
	<!-- Accordion -->
<div id="accordion">
	
<h3><strong>பாடல் </strong>மற்றும் குறியீட்டு எண்</h3>
<div style="height:490px;">
  <table>
<tr><td>     
  <div align="justify"><span style="color: rgb(153, 51, 102);">பிஎஸ்என்எல் வாடிக்கையாளர்கள் தமது செல்பேசியில் பகுத்தறிவுப்&nbsp; பாடல்களை பதிவிறக்கம் செய்ய ,&nbsp;<span style="color: rgb(0, 0, 0);"><strong>BT &lt; SPACE&gt; ACT &lt; space&gt; Song Code</strong></span> _ டைப் செய்து <span style="color: rgb(0, 0, 0);"><strong>56700</strong></span> என்ற எண்ணுக்கு குறுந்தகவல்<span style="color: rgb(0, 0, 0);"> <strong>(SMS)</strong></span> செய்யவும். உதாரணமாக கீழ்கண்ட பாடல்களில் ஒன்றை தரவிறக்கம் செய்ய    <span style="color: rgb(0, 0, 0);"><strong>‘BT ACT 552340’ </strong></span>என்று டைப் செய்து <strong><span style="color: rgb(0, 0, 0);">56700</span> </strong>என்ற எண்ணுக்கு அனுப்பினால் பகுத்-தறிவுப் பாடல்கள் உங்கள் கைத் தொலை-பேசியை வந்தடையும். ஏற்கெனவே வேறு <strong><span style="color: rgb(0, 0, 0);">Caller Tune</span></strong> வைத்திருப்பர்கள் <span style="color: rgb(0, 0, 0);"><strong>‘BT 552340’</strong></span> என்ற வடிவத்தில் டைப் செய்து அனுப்பினால் போதுமானது.</span>  </div></td></tr>
</table>
</br></br>
<table width="800" border="0" align="center" cellspacing="4" height="540" style="overflow-y: scroll;">
<tr>
            <td>தமிழினத்தின்</td>
            <td><div>552340</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">

<audio controls>
  
  <source src="/callertunes/29 Thamizinathin.mp3" type="audio/mpeg">

</audio>

</object></td>
            <td>தன்மான சிங்கமே</td>
            <td><div>552353</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">
<audio controls>
  
  <source src="/callertunes/30 Thanmaana singame.mp3" type="audio/mpeg">

</audio>


</object></td>
          </tr>
          <tr>
            <td>எங்கும் இருக்கின்றார்</td>
            <td><div>552360</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">

<audio controls>
  
  <source src="/callertunes/23 Engum irukindraar.mp3" type="audio/mpeg">

</audio>


</object>

</td>
            <td>செந்தமிழ் நாட்டினிலே - 1</td>
            <td><div>552338</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">

<audio controls>
  
  <source src="/callertunes/06 Senthamil naatinile 1.mp3" type="audio/mpeg">

</audio>


</object>



</td>
          </tr>
          <tr>
            <td>ஜாதி ஜாதி</td>
            <td><div>552351</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">

<audio controls>
  
  <source src="/callertunes/12 Jaadhi jaadhi.mp3" type="audio/mpeg">

</audio>
</object></td>
            <td>செந்தமிழ் நாட்டினிலே - 2</td>
            <td><div>552334</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">

<audio controls>
  
  <source src="/callertunes/05 Senthamil naatinile.mp3" type="audio/mpeg">

</audio>
</object></td>
          </tr>
          <tr>
            <td>தொண்டு - 1</td>
            <td><div>552337</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">

<audio controls>
  
  <source src="/callertunes/20 Thondu.mp3" type="audio/mpeg">

</audio>
</object></td>
            <td>ஆடு மயிலே</td>
            <td><div>552362</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">

<audio controls>
  
  <source src="/callertunes/08 Aadu mayile.mp3" type="audio/mpeg">

</audio>
</object></td>
          </tr>
          <tr>
            <td>தொண்டு - 2</td>
            <td><div>552331</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">

<audio controls>
  
  <source src="/callertunes/21 Thondu.mp3" type="audio/mpeg">

</audio>

</object></td>
            <td>பெரியார் பெரியார்</td>
            <td><div>552343</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">

<audio controls>
  
  <source src="/callertunes/28 periyar periyar.mp3" type="audio/mpeg">

</audio>
</object></td>
          </tr>
          <tr>
            <td>நம் நாடு நம் நாடு - 1</td>
            <td><div>552358</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">

<audio controls>
  
  <source src="/callertunes/13 Nam Naadu nam Naadu.mp3" type="audio/mpeg">

</audio>
</object></td>
            <td>பொன்னுறவாகிய</td>
            <td><div>552335</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">

<audio controls>
  
  <source src="/callertunes/25 Ponnuruvagiya.mp3" type="audio/mpeg">

</audio>
</object></td>
          </tr>
          <tr>
            <td>நம் நாடு நம் நாடு - 2</td>
            <td><div>552354</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">

<audio controls>
  
  <source src="/callertunes/14 Nam Naadu nam Naadu_L.mp3" type="audio/mpeg">

</audio>
</object></td>
            <td>பார் உலகில</td>
            <td><div>552349</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">

<audio controls>
  
  <source src="/callertunes/22 Paarulagil.mp3" type="audio/mpeg">

</audio>
</object></td>
          </tr>
          <tr>
            <td>பெரியாரை</td>
            <td><div>552332</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">

<audio controls>
  
  <source src="/callertunes/11 Periyarai.mp3" type="audio/mpeg">

</audio>
</object></td>
            <td>வான் தவழும்</td>
            <td><div>552350</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">

<audio controls>
  
  <source src="/callertunes/10 Vaan thavalum.mp3" type="audio/mpeg">

</audio>
</object></td>
          </tr>
          <tr>
            <td>தோழா வா தோழா</td>
            <td><div>552333</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">

<audio controls>
  
  <source src="/callertunes/16 Thoza vaa thoza.mp3" type="audio/mpeg">

</audio>
</object></td>
            <td>ஈரோட்டுச் சிங்கமடா</td>
            <td><div>552361</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">

<audio controls>
  
  <source src="/callertunes/04 Erottu singamada.mp3" type="audio/mpeg">

</audio>
</object></td>
          </tr>
          <tr>
            <td>அவர்தான் வீரமணி</td>
            <td><div>552345</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">

<audio controls>
  
  <source src="/callertunes/03 avarthan veeramani.mp3" type="audio/mpeg">

</audio>
</object></td>
            <td>இன்னும் அடிமையா?</td>
            <td><div>552341</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">

<audio controls>
  
  <source src="/callertunes/26 Innum adimaya.mp3" type="audio/mpeg">

</audio>
</object></td>
          </tr>
          <tr>
            <td>உலகாண்டிடும் தலைவர்</td>
            <td><div>552357</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">

<audio controls>
  
  <source src="/callertunes/31 Ulagaandidum thalaivar.mp3" type="audio/mpeg">

</audio>
</object></td>
            <td>அய்யாவின்</td>
            <td><div>552348</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">

<audio controls>
  
  <source src="/callertunes/15 Ayyavin.mp3" type="audio/mpeg">

</audio>
</object></td>
          </tr>
          <tr>
            <td>தோழர்களே</td>
            <td><div>552336</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">

<audio controls>
  
  <source src="/callertunes/18 Thozarkale.mp3" type="audio/mpeg">

</audio>
</object></td>
            <td>அவர்தாம் பெரியார் - 1</td>
            <td><div>552359</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">

<audio controls>
  
  <source src="/callertunes/02 Avarthaan periyar 2.mp3" type="audio/mpeg">

</audio>
</object></td>
          </tr>
          <tr>
            <td>தாலியாம் தாலி</td>
            <td><div>552356</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">

<audio controls>
  
  <source src="/callertunes/09 thaliyam thali.mp3" type="audio/mpeg">

</audio>
</object></td>
            <td>அவர்தாம் பெரியார் - 2</td>
            <td><div>552344</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">

<audio controls>
  
  <source src="/callertunes/02 Avarthaan periyar 2.mp3" type="audio/mpeg">

</audio>
</object></td>
          </tr>
          <tr>
            <td>தமிழரெல்லாம் மானத்தோடு</td>
            <td><div>552355</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">

<audio controls>
  
  <source src="/callertunes/07 Thamilarellam maanathodu.mp3" type="audio/mpeg">

</audio>
</object></td>
            <td>பக்தி வந்தா...</td>
            <td><div>552346</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">

<audio controls>
  
  <source src="/callertunes/27 Bakthi vandhaa.mp3" type="audio/mpeg">

</audio>
</object></td>
          </tr>
          <tr>
            <td>பெண்ணே! பெண்ணே! திரும்பிப் பார்</td>
            <td><div>552352</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">

<audio controls>
  
  <source src="/callertunes/19 Penne Penne thirumbipaar.mp3" type="audio/mpeg">

</audio>
</object></td>
            <td height="23">பத்துவயதில்</td>
            <td><div>552342</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">

<audio controls>
  
  <source src="/callertunes/17 Pathuvayathil.mp3" type="audio/mpeg">

</audio>
</object></td>
          </tr>
          <tr>
            <td>சகுனம் பாத்து</td>
            <td><div>552339</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">
<audio controls>
  
  <source src="/callertunes/24 Sagunam paathu.mp3" type="audio/mpeg">

</audio>
</object></td>
            <td height="23">பெரியார் திடல்</td>
            <td><div>552347</div></td>
            <td><object id="audioplayer_11" width="80" height="16" type="application/x-shockwave-flash" name="audioplayer_11" style="outline: none" data="flash/player.swf">
<param name="bgcolor" value="#FFFFFF">
<param name="wmode" value="transparent">
<param name="menu" value="false">
<audio controls>
  
  <source src="/callertunes/32 Periyar thidal.mp3" type="audio/mpeg">

</audio>
</object></td>
          </tr>         
    </table>
     
</div>
<?php include_once("templates/footer.php") ?>