document.addEventListener("DOMContentLoaded", function() { startplayer(); }, false);
var player;

function startplayer() 
{
 player = document.getElementById('music_player');
 player.controls = false;
}

function play_aud() 
{
 player.play();
} 
function pause_aud() 
{
 player.pause();
}
function stop_aud() 
{
 player.pause();
 player.currentTime = 0;
}
function change_vol()
{
 player.volume=document.getElementById("change_vol").value;
}

function playthis(id){
	var sid=document.getElementById(id);
	var audio1=sid.getAttribute("data-audio");
	var imge=sid.src;
	var title1=sid.getAttribute("data-atitle");
	//document.getElementById("audiofile").src=audio;
	document.getElementById("audiofile").setAttribute("src",audio1);
	document.getElementById("audioimage").src=imge;
	document.getElementById("headtitle").innerHTML=title1;
 var x = document.getElementById("music_player");

    x.load();
x.play();

	
	}
	
	