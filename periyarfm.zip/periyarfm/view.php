<?php
include_once("connection.php");

if(isset($_GET["cateid"]))
{
	$id=$_GET["cateid"];
	header("Location:index1.php?cateid=$id");
	
}
if($_GET["play"]){
$id=($_GET["play"])/(47);
$select1='select Audio_Id,Audio_Album,Audio_File,Audio_Title,Audio_Descript,Category_Name,am.Category_Id from audio_manager as am,category_manager as cm where am.Category_Id=cm.Category_Id and am.Audio_Id='.$id;
 $qery=mysql_query($select1);
$fetchrow=mysql_fetch_row($qery);
 $mp=new SplFileInfo($fetchrow[2]);
$af=$mp->getExtension();

echo '<audio id="audio-player"  src="http://periyar.fm/admin/upload/audio_file/'.$fetchrow[2].'" type="audio/mp3" autoplay controls download="'.$fetchrow[2].'"></audio>';
}
else
{
	

}

if(isset($_GET["cateid1"]))
{
	
	$cid=$_GET["cateid"]/(49);
	$select='select Distinct Audio_Id,Audio_Album,Audio_File,Audio_Title,Audio_Descript,Category_Name,am.Category_Id from audio_manager as am,category_manager as cm where am.Category_Id=cm.Category_Id and cm.Category_Id='.$cid.' order by Audio_Id Desc';
	
		$exe=mysql_query($select);
		if(!$exe)
		{
		echo mysql_error();
		}
		$cnt=mysql_num_rows($exe);
	
		if($cnt>0)
		{
			$i=1;
			while($row=mysql_fetch_array($exe,MYSQL_BOTH))
			{					
				//echo '<div class="media"><div class="media-left media-middle"><a  onclick="playview()" urldata="http://periyar.fm/admin/upload/audio_file/'.$row[2].'" id="audioplay"><img class="media-object" src="http://periyar.fm/admin/upload/image_file/'.$row[1].'" alt="'.trim($row[3];.'"></a></div><div class="media-body"><h4 class="media-heading">'.trim($row[3]);.'</h4>'.trim($row[4]);.'</div></div>';
				
								/*$twitterURL = 'https://twitter.com/intent/tweet?text='.$hrow[3].'&amp;url=http://periyar.fm/admin/upload/audio_file/'.$row[2].'&amp;via=periyarfm';
		$facebookURL = 'https://www.facebook.com/sharer/sharer.php?u=http://periyar.fm/admin/upload/audio_file/'.$row[2];
		$googleURL = 'https://plus.google.com/share?url=http://periyar.fm/admin/upload/audio_file/'.$fetchrow[2];
		$bufferURL = 'https://bufferapp.com/add?url=http://periyar.fm/admin/upload/audio_file/'.$fetchrow[2].'&amp;text='.$row[3];
		$linkedInURL = 'https://www.linkedin.com/shareArticle?mini=true&url=http://periyar.fm/admin/upload/audio_file/'.$row[2].'&amp;title='.$row[3];
				echo '<div class="col-md-3"><div class="media thumbnail" onclick="playview(this.id)" urldata="http://periyar.fm/admin/upload/audio_file/'.$row[2].'" id="'.rand().'" title="'.$row[3].'" imageurl="http://periyar.fm/admin/upload/image_file/'.$row[1].'" category="'.$row1["1"].'"><div class="media-left media-middle"> <img class="media-object img-thumbnail " src="http://periyar.fm/admin/upload/image_file/'.$row[1].'" alt="'.$row[3].'" width="80px" height="80px"></div><div class="media-body"><h6 class="media-heading"><span class="glyphicon glyphicon-play" aria-hidden="true"></span>'.$row[3].'</h6><p>'.$row[4].'<a href="'.$facebookURL.'">Facebook</a>|
		<a href="'.$twitterURL.'">Twitter</a>|
		<a href="'.$linkedInURL.'">Linkedin</a>|
		<a href="'.$googleURL.'">Google+</a><p></div></div></div>';           	
		
		*/


				
				
				if($i==1){
					
				echo '<div class="col-md-1"><div style="cursor:pointer;" data-toggle="tooltip" data-placement="top" class="" onclick="playview(this.id)" urldata="http://periyar.fm/admin/upload/audio_file/'.$row[2].'" id="'.rand().'" title="'.$row[3].'" imageurl="http://periyar.fm/admin/upload/image_file/'.$row[1].'" category="'.$row1["1"].'"> <figure><img class="img-responsive" src="http://periyar.fm/admin/upload/image_file/'.$row[1].'" alt="'.$row[3].'"> <figcaption>'.$row[3].'</figcaption></figure></div></div>';
				

				}
				elseif($i==2){
							echo '<div class="col-md-1"><div style="cursor:pointer;" data-toggle="tooltip" data-placement="top" class="" onclick="playview(this.id)" urldata="http://periyar.fm/admin/upload/audio_file/'.$row[2].'" id="'.rand().'" title="'.$row[3].'" imageurl="http://periyar.fm/admin/upload/image_file/'.$row[1].'" category="'.$row1["1"].'"> <figure><img class="img-responsive" src="http://periyar.fm/admin/upload/image_file/'.$row[1].'" alt="'.$row[3].'"> <figcaption>'.$row[3].'</figcaption></figure></div></div>';
				}
				
				elseif($i==3){
									echo '<div class="col-md-1"><div style="cursor:pointer;" data-toggle="tooltip" data-placement="top" class="" onclick="playview(this.id)" urldata="http://periyar.fm/admin/upload/audio_file/'.$row[2].'" id="'.rand().'" title="'.$row[3].'" imageurl="http://periyar.fm/admin/upload/image_file/'.$row[1].'" category="'.$row1["1"].'"> <figure><img class="img-responsive" src="http://periyar.fm/admin/upload/image_file/'.$row[1].'" alt="'.$row[3].'"> <figcaption>'.$row[3].'</figcaption></figure></div></div>';
				}
				elseif($i==4){
							echo '<div class="col-md-1"><div style="cursor:pointer;" data-toggle="tooltip" data-placement="top" class="" onclick="playview(this.id)" urldata="http://periyar.fm/admin/upload/audio_file/'.$row[2].'" id="'.rand().'" title="'.$row[3].'" imageurl="http://periyar.fm/admin/upload/image_file/'.$row[1].'" category="'.$row1["1"].'"> <figure><img class="img-responsive" src="http://periyar.fm/admin/upload/image_file/'.$row[1].'" alt="'.$row[3].'"> <figcaption>'.$row[3].'</figcaption></figure></div></div>';
				}
				
				elseif($i==5){
							echo '<div class="col-md-1"><div style="cursor:pointer;" data-toggle="tooltip" data-placement="top" class="" onclick="playview(this.id)" urldata="http://periyar.fm/admin/upload/audio_file/'.$row[2].'" id="'.rand().'" title="'.$row[3].'" imageurl="http://periyar.fm/admin/upload/image_file/'.$row[1].'" category="'.$row1["1"].'"> <figure><img class="img-responsive" src="http://periyar.fm/admin/upload/image_file/'.$row[1].'" alt="'.$row[3].'"> <figcaption>'.$row[3].'</figcaption></figure></div></div>';
				}
				
				elseif($i==6){
							echo '<div class="col-md-1"><div style="cursor:pointer;" data-toggle="tooltip" data-placement="top" class="" onclick="playview(this.id)" urldata="http://periyar.fm/admin/upload/audio_file/'.$row[2].'" id="'.rand().'" title="'.$row[3].'" imageurl="http://periyar.fm/admin/upload/image_file/'.$row[1].'" category="'.$row1["1"].'"> <figure><img class="img-responsive" src="http://periyar.fm/admin/upload/image_file/'.$row[1].'" alt="'.$row[3].'"> <figcaption>'.$row[3].'</figcaption></figure></div></div>';
				}
				
				elseif($i==7){
							echo '<div class="col-md-1"><div style="cursor:pointer;" data-toggle="tooltip" data-placement="top" class="" onclick="playview(this.id)" urldata="http://periyar.fm/admin/upload/audio_file/'.$row[2].'" id="'.rand().'" title="'.$row[3].'" imageurl="http://periyar.fm/admin/upload/image_file/'.$row[1].'" category="'.$row1["1"].'"> <figure><img class="img-responsive" src="http://periyar.fm/admin/upload/image_file/'.$row[1].'" alt="'.$row[3].'"> <figcaption>'.$row[3].'</figcaption></figure></div></div>';
				}
				
				elseif($i==8){
							echo '<div class="col-md-1"><div style="cursor:pointer;" data-toggle="tooltip" data-placement="top" class="" onclick="playview(this.id)" urldata="http://periyar.fm/admin/upload/audio_file/'.$row[2].'" id="'.rand().'" title="'.$row[3].'" imageurl="http://periyar.fm/admin/upload/image_file/'.$row[1].'" category="'.$row1["1"].'"> <figure><img class="img-responsive" src="http://periyar.fm/admin/upload/image_file/'.$row[1].'" alt="'.$row[3].'"> <figcaption>'.$row[3].'</figcaption></figure></div></div>';
				}
				
				elseif($i==9){
							echo '<div class="col-md-1"><div style="cursor:pointer;" data-toggle="tooltip" data-placement="top" class="" onclick="playview(this.id)" urldata="http://periyar.fm/admin/upload/audio_file/'.$row[2].'" id="'.rand().'" title="'.$row[3].'" imageurl="http://periyar.fm/admin/upload/image_file/'.$row[1].'" category="'.$row1["1"].'"> <figure><img class="img-responsive" src="http://periyar.fm/admin/upload/image_file/'.$row[1].'" alt="'.$row[3].'"> <figcaption>'.$row[3].'</figcaption></figure></div></div>';
				}
				
				elseif($i==10){
							echo '<div class="col-md-1"><div style="cursor:pointer;" data-toggle="tooltip" data-placement="top" class="" onclick="playview(this.id)" urldata="http://periyar.fm/admin/upload/audio_file/'.$row[2].'" id="'.rand().'" title="'.$row[3].'" imageurl="http://periyar.fm/admin/upload/image_file/'.$row[1].'" category="'.$row1["1"].'"> <figure><img class="img-responsive" src="http://periyar.fm/admin/upload/image_file/'.$row[1].'" alt="'.$row[3].'"> <figcaption>'.$row[3].'</figcaption></figure></div></div>';
				}
				
				elseif($i==11){
							echo '<div class="col-md-1"><div style="cursor:pointer;" data-toggle="tooltip" data-placement="top" class="thumbnail" onclick="playview(this.id)" urldata="http://periyar.fm/admin/upload/audio_file/'.$row[2].'" id="'.rand().'" title="'.$row[3].'" imageurl="http://periyar.fm/admin/upload/image_file/'.$row[1].'" category="'.$row1["1"].'"> <img class="img-thumbnail img-responsive" src="http://periyar.fm/admin/upload/image_file/'.$row[1].'" alt="'.$row[3].'" width="" height=""><p style="font-size:10px;">'.$row[3].'</p></div></div>';
				}
				elseif($i==12){
							echo '<div class="col-md-1"><div style="cursor:pointer;" data-toggle="tooltip" data-placement="top" class="thumbnail" onclick="playview(this.id)" urldata="http://periyar.fm/admin/upload/audio_file/'.$row[2].'" id="'.rand().'" title="'.$row[3].'" imageurl="http://periyar.fm/admin/upload/image_file/'.$row[1].'" category="'.$row1["1"].'"> <img class="img-thumbnail img-responsive" src="http://periyar.fm/admin/upload/image_file/'.$row[1].'" alt="'.$row[3].'" width="" height=""><p style="font-size:10px;">'.$row[3].'</p></div></div>';
				}
				
				
				if($i==10){
					$i=1;
				}
				else{
				$i++;	
				}
				
			
			}
			
			
		}
}




if(isset($_POST["submit"]))
{
$temp = explode(".", $_FILES["fileToUpload"]["name"]);
//$temp = $_FILES["fileToUpload"]["name"];
$newfilename ="arul".'.' . end($temp);
move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], "news/".$newfilename);
}

/*image file rename


$select1='select Audio_Id,Audio_Album,Audio_File,Audio_Title,Audio_Descript,Category_Name,am.Category_Id from audio_manager as am,category_manager as cm where am.Category_Id=1' ;
 $qery=mysql_query($select1);
 $oldfile="news/arul.jpg";
while($fetchrow=mysql_fetch_array($qery)){
	$value="news/".$fetchrow[1];
if (!copy($oldfile, $value)) {
    echo "failed to copy $file...\n";
}
}

*/

?>
<!--<form action="" method="post" enctype="multipart/form-data">
    Select image to upload:
    <input type="file" name="fileToUpload" id="fileToUpload">
    <input type="submit" value="Upload Image" name="submit">
</form>-->