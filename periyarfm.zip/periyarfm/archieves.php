<?php 
	if(!is_numeric($_GET["catid"])){
		header("Location:index.php");
	}
	include_once("templates/header.php");
	include_once("functions.php");
	$section = parse_ini_file("config.ini");
	switch($_GET["catid"]) {
		case 1 :
			$section_disp = $section["TITLE_1"];
		break;
		case 2 :
			$section_disp = $section["TITLE_2"];
		break;
		case 3 :
			$section_disp = $section["TITLE_3"];
		break;
		case 4 :
			$section_disp = $section["TITLE_4"];
		break;
		case 5 :
			$section_disp = $section["TITLE_5"];
		break;
		case 6 :
			$section_disp = $section["TITLE_6"];
		break;
		case 9 :
			$section_disp = $section["TITLE_9"];
		break;
	}
?>
<div id="leftcolumn">
<script>
  window.fbAsyncInit = function() {
    FB.init({
      appId      : '289308724740937',
      xfbml      : true,
      version    : 'v2.6'
    });
  };

  (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = "//connect.facebook.net/en_US/sdk.js";
     fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));
</script>
<!--<textarea style="margin:10px 0px 0px 10px;padding-left:5px;width:210px;background-color:#CCCCCC;">
&lt;iframe src="http://www.goo.gl/vnuw3" width="250px" height="100%" frameborder="0"&gt;
&lt;/iframe&gt;
</textarea>-->
<iframe src="playlist.php" width="250px" height="500" frameborder="0">
  <p>Your browser does not support iframes.</p>
</iframe>
</div>

<div id="content" style="padding:9px 4px 25px 4px;height:100%">
	<!-- Accordion -->
			 <div id="accordion" style="height:100%">
				<div>
					<h3><a href="#"><?php echo $section_disp; ?> </a></h3>
					<div><?php 
					if($_GET["catid"] == 1) {
						$limit = 1000;
					} else {
						$limit = 1000;
					}
					echo ArchieveAudioDisplay($_GET["catid"],$limit); 
					
					?></div>
				</div>					
			</div>

</div>
<?php include_once("templates/footer.php") ?>