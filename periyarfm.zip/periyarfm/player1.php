<?php 
	include_once("functions.php");	
	$disp = AudioPlay($_GET["audioid"]);	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
		<META NAME="Description" CONTENT="<?php echo $disp["meta"];?>">
		<title>பெரியார் பண்பலை</title>
		<link type="text/css" href="css/jquery-ui-1.8.16.custom.css" rel="stylesheet" />	
		<script type="text/javascript" src="js/audio-player.js"></script>
		<script type="text/javascript" src="js/jquery-1.6.2.min.js"></script>
		<script type="text/javascript" src="js/popup.js"></script>
		<script type="text/javascript" src="js/jquery-ui-1.8.16.custom.min.js"></script>			
		<script type="text/javascript">
			$(function(){

			// Accordion
				$("#accordion").accordion({ header: "h3" });
								
			});
			AudioPlayer.setup("flash/player.swf", {  
			width: 290,  
			initialvolume: 100,  
			transparentpagebg: "yes",  
			left: "000000",  
			lefticon: "FFFFFF"  
			});
			function ShowDescript() {
				alert("hello world");
			}
			$(document).ready(function() {
			
			//Tooltips
			$(".tip_trigger").hover(function(){
				tip = $(this).find('.tip');
				tip.show(); //Show tooltip
			}, function() {
				tip.hide(); //Hide tooltip		  
			}).mousemove(function(e) {
				var mousex = e.pageX + 20; //Get X coodrinates
				var mousey = e.pageY + 20; //Get Y coordinates
				var tipWidth = tip.width(); //Find width of tooltip
				var tipHeight = tip.height(); //Find height of tooltip
				
				//Distance of element from the right edge of viewport
				var tipVisX = $(window).width() - (mousex + tipWidth);
				//Distance of element from the bottom of viewport
				var tipVisY = $(window).height() - (mousey + tipHeight);
				  
				if ( tipVisX < 20 ) { //If tooltip exceeds the X coordinate of viewport
					mousex = e.pageX - tipWidth - 20;
				} if ( tipVisY < 20 ) { //If tooltip exceeds the Y coordinate of viewport
					mousey = e.pageY - tipHeight - 20;
				} 
				tip.css({  top: mousey, left: mousex });
			});
			});
		</script>
<style type="text/css">
			/*demo page css*/
			body{ font: 62.5% "Trebuchet MS", sans-serif; margin: 50px;}
			.demoHeaders { margin-top: 2em; }
			#dialog_link {padding: .4em 1em .4em 20px;text-decoration: none;position: relative;}
			#dialog_link span.ui-icon {margin: 0 5px 0 0;position: absolute;left: .2em;top: 50%;margin-top: -8px;}
			ul#icons {margin: 0; padding: 0;}
			ul#icons li {margin: 2px; position: relative; padding: 4px 0; cursor: pointer; float: left;  list-style: none;}
			ul#icons span.ui-icon {float: left; margin: 0 4px;}
				/*template style*/
				body {
				margin: 0px;
				padding: 0px;
				}
				#header {
				width: 1000px;
				height: 100px;
				}
				#leftcolumn {
				float: right;
				width: 240px;
				height: 100%;
				margin-top:5px 0px 0px 0px;
				}
				#content {
				float: left;
				width: 740px;
				height: 100%;
				}
				#footer {
				margin-top:100px;
				background: #df781c;
				float:left;
				width:1024px;
				height:20px;
				color:white;
				text-align:center;
				font-size;200%;
				vertical-align:text-top;			
				}
	.column { width: 170px; float: left; padding-bottom: 100px; }
	.portlet { margin: 0 1em 1em 0; }
	.portlet-header { margin: 0.3em; padding-bottom: 4px; padding-left: 0.2em; }
	.portlet-header .ui-icon { float: right; }
	.portlet-content { padding: 0.4em; }
	.ui-sortable-placeholder { border: 1px dotted black; visibility: visible !important; height: 50px !important; }
	.ui-sortable-placeholder * { visibility: hidden; }
	
	
	table.gridtable {
		font-family: verdana,arial,sans-serif;
		font-size:11px;
		color:#333333;
		border-width: 1px;
		border-color: #666666;
		border-collapse: collapse;
	}
	table.gridtable th {
		border-width: 1px;
		padding: 8px;
		border-style: solid;
		border-color: #666666;
		background-color: #dedede;
	}
	table.gridtable td {
		border-width: 1px;
		padding: 8px;
		border-style: solid;
		border-color: #666666;
		background-color: #ffffff;
	}
	
		/* menu header */
		.mattblacktabs{
		width:1024px;
		overflow: hidden;
		background-color:#000000;
		}

		.mattblacktabs ul{
		margin:0;
		padding:0;
		font: bold 12px Verdana;
		list-style-type: none;		
		}

		.mattblacktabs li{
		display: inline;
		margin: 0;
		}

		.mattblacktabs li a{
		float: left;
		display: block;
		text-decoration: none;
		margin: 0;
		padding: 7px 8px; /*padding inside each tab*/
		border-right: 1px solid white; /*right divider between tabs*/
		color: white;
		background: #414141; /*background of tabs (default state)*/
		}

		.mattblacktabs li a:visited{
		color: white;
		}

		.mattblacktabs li a:hover, .mattblacktabs li.selected a{
		background: black; /*background of tabs for hover state, plus tab with "selected" class assigned to its LI */
		}
	/* menu header */
	/*--Tooltip Styles--*/
	.tip {
		color: #fff;
		background:#1d1d1d;
		display:none; /*--Hides by default--*/
		padding:10px;
		position:absolute;
		z-index:1000;
		-webkit-border-radius: 3px;
		-moz-border-radius: 3px;
		border-radius: 3px;
	}		
</style>	
</head>
<body>
	<table width="1000px" align="center">
	<tr><td>
	<div id="header"><img src="images/periyar.jpg"/></div>
		<div class="mattblacktabs" style="padding:0px 0px 5px 0px;">
			<ul>
			<li><a href="index.php">&nbsp;Home&nbsp;</a></li>
			<li><a href="callertunes.php">&nbsp;Callertunes&nbsp;</a></li>
			<li><a href="http://www.Periyar.org" target="_blank">&nbsp;Periyar&nbsp;</a></li>
			<li><a href="http://www.viduthalai.com" target="_blank">&nbsp;Viduthalai&nbsp;</a></li>
			<li><a href="http://www.unmaionline.com" target="_blank">&nbsp;Unmai&nbsp;</a></li>
			<li><a href="http://www.periyarpinju.com" target="_blank">&nbsp;Periyarpinju&nbsp;</a></li>
			<li><a href="http://www.periyarmatrimonial.com/" target="_blank">&nbsp;Matrimonial&nbsp;</a></li>
			<li><a href="http://www.modernrationalist.com/" target="_blank">&nbsp;The Modern Rationalist&nbsp;</a></li>
			<li><a href="http://www.periyar.tv/" target="_blank">Periyar Tv</a></li>
			<li><a href="http://www.worldatheistconference.com/wac.html" target="_blank">World Atheist</a></li>			
			</ul>
		</div>
<div id="content" style="margin-top:200px;height:250px;width:1020px;" align="center">
	<!-- Accordion -->
			 <div id="accordion" style="height:100%">
				<div>
					<h3><a href="#"><?php echo $section_disp; ?> </a></h3>
					<div><?php 
					if($_GET["catid"] == 1) {
						$limit = 8;
					} else {
						$limit = 100;
					}
					echo $disp["disp"]; 
					?></div>
				</div>					
			</div>

</div>
<?php include_once("templates/footer.php") ?>